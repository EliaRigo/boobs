/**
 * Created by ivanmorandi on 04/12/14.
 */
var info = {
    Rooms:[]

};

room = (function(){


    function cls()
    {
        var Name;
        var Quantita;
        var Piano;
        var Polo;
        var Lavagna;
        var Rumore;
        var Feedback;

        var self = this;


    }
});